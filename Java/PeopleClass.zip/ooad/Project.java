package ooad;

public class Project {
    private String projectName;
    private String status;
    private String comment;
}
